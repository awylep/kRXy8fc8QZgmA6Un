package com.awi.appsba.api;


import com.awi.appsba.model.ResponsModelkrr;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiRequestBiodatakrr {
    @FormUrlEncoded
    @POST("datakurir.php")
    Call<ResponsModelkrr> sendBiodatakrr (@Field("username") String username,
                                          @Field("nama") String nama,
                                          @Field("instansi") String instansi,
                                          @Field("unit") String unit,
                                          @Field("tanggal") String tanggal,
                                          @Field("jam") String jam,
                                          @Field("hari") String hari,
                                          @Field("akti") String akti,
                                          @Field("lokasi") String lokasi,
                                          @Field("nama jumpa") String namajumpa,
                                          @Field("nohp jumpa") String nohpjumpa,
                                          @Field("email jumpa") String emailjumpa,
                                          @Field("unit jumpa") String unitjumpa);

    @GET("read.php")
    Call<ResponsModelkrr> getBiodatakrr();

    @FormUrlEncoded
    @POST("update.php")
    Call<ResponsModelkrr> updateDatakrr (@Field("username") String username,
                                  @Field("nama") String nama,
                                  @Field("instansi") String instansi,
                                  @Field("unit") String unit,
                                  @Field("tanggal") String tanggal,
                                  @Field("jam") String jam,
                                  @Field("hari") String hari,
                                  @Field("akti") String akti,
                                  @Field("lokasi") String lokasi,
                                  @Field("nama jumpa") String namajumpa,
                                  @Field("nohp jumpa") String nohpjumpa,
                                  @Field("email jumpa") String emailjumpa,
                                  @Field("unit jumpa") String unitjumpa);

    @FormUrlEncoded
    @POST("delete.php")
    Call<ResponsModelkrr> deleteDatakrr (@Field("username") String username);

    Call<ResponsModelkrr> sendBiodatakrr(String snama, String susername, String sinstansi, String stggl, String sjam, String shari, String snamajumpa, String snohpjumpa, String semailjumpa);
}
