package com.awi.appsba.api;

import com.awi.appsba.model.ResponsModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiRequestBiodata {

    @FormUrlEncoded
    @POST("datakrywn.php")
    Call<ResponsModel> sendBiodata(@Field("username") String username,
                                   @Field("nama") String nama,
                                   @Field("instansi") String instansi,
                                   @Field("unit") String unit,
                                   @Field("tggl") String tggl,
                                   @Field("jam") String jam,
                                   @Field("hari") String hari,
                                   @Field("akti") String akti,
                                   @Field("lokasi") String lokasi,
                                   @Field("nama jumpa") String namajumpa);

    @GET("read.php")
    Call<ResponsModel> getBiodata();

    @FormUrlEncoded
    @POST("update.php")
    Call<ResponsModel> updateData(@Field("username") String username,
                                  @Field("nama") String nama,
                                  @Field("instansi") String instansi,
                                  @Field("unit") String unit,
                                  @Field("tggl") String tggl,
                                  @Field("jam") String jam,
                                  @Field("hari") String hari,
                                  @Field("akti") String akti,
                                  @Field("lokasi") String lokasi,
                                  @Field("nama jumpa") String namajumpa,
                                  @Field("nohp jumpa") String nohpjumpa,
                                  @Field("email jumpa") String emailjumpa,
                                  @Field("unit jumpa") String unitjumpa);

    @FormUrlEncoded
    @POST("delete.php")
    Call<ResponsModel> deleteData(@Field("username") String username);
}
