package com.awi.appsba.activity;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.awi.appsba.R;


public class nonkaryawan_in extends AppCompatActivity {
    RadioGroup rg;
    Button terima;
    EditText Susername, Snama, Snohp, Sdom, Sjalan, Sinstansi, Stgl, Sjam, Shari, Snamajumpa, Snohpjumpa, Slain, Semailjumpa;
Spinner Slokasi, Sunitjumpaa;
    String lokasi_list, unit_list;
private String nama, username, nohp, dom, jalan, instansi, tgl, jam, hari,  namajumpa, nohpjumpa, emailjumpa, lokasi,akti, unitjumpa;

    private ProgressBar loadingPB;
    private Object String;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


/////////////////////////////////////////SPINNER//////////////////////////////
 /*
        String[] lokasi_list = getResources().getStringArray(R.array.lokasi_list);
        ArrayAdapter<String> adappter = new ArrayAdapter<String>(this, R.layout.spinloka, R.id.txspinloka, lokasi_list);
        Slokasi.setAdapter(adappter);

        String[] unit_list = getResources().getStringArray(R.array.unit_list);
        ArrayAdapter<String> adapterr = new ArrayAdapter<String>(this, R.layout.spinloka, R.id.txspinunit, unit_list);
        Sunitjumpaa.setAdapter(adapterr); */
//////////////////////////////////////////////////////////////////////////////

        Snama = (EditText) findViewById(R.id.namatamu);
        Susername = (EditText) findViewById(R.id.ktptamu);
        Snohp = (EditText) findViewById(R.id.notamu);
        Sdom = (EditText) findViewById(R.id.domisilitamu);
        Sjalan = (EditText) findViewById(R.id.kunjungi);
        Sinstansi = (EditText) findViewById(R.id.nama_perusahaantamu);
        Stgl = (EditText) findViewById(R.id.tanggaltamu);
        Sjam = (EditText) findViewById(R.id.jamtamu);
        Shari = (EditText) findViewById(R.id.hari);
        Slain = (EditText) findViewById(R.id.edlain);
        Sunitjumpaa = (Spinner) findViewById(R.id.spinner6);
        Snamajumpa = findViewById(R.id.ed_namajumpa);
        Snohpjumpa = findViewById(R.id.ed_nohpjumpa);
        Semailjumpa = findViewById(R.id.ed_emailjumpa);
        Slokasi = (Spinner) findViewById(R.id.spinner7);
        terima = (Button) findViewById(R.id.ajukanjumpa);
        loadingPB = findViewById(R.id.idLoadingPB);

///////////////////////////////////////////////////////////////////////////////

        username = Susername.getText().toString();
        nama = Snama.getText().toString();
        nohp = Snohp.getText().toString();
        instansi = Sinstansi.getText().toString();
        dom = Sdom.getText().toString();
        jalan = Sjalan.getText().toString();
        instansi = Sinstansi.getText().toString();
        tgl = Stgl.getText().toString();
        jam = Sjam.getText().toString();
        hari = Shari.getText().toString();
        akti = Slain.getText().toString();
        namajumpa = Snamajumpa.getText().toString();
        nohpjumpa = Snohpjumpa.getText().toString();
        emailjumpa = Semailjumpa.getText().toString();
        unitjumpa = Sunitjumpaa.getSelectedItem().toString();
        lokasi = Slokasi.getSelectedItem().toString();



///////////////////////////////////////////////////////////////////////////////
   }
}

//         terima.setOnClickListener(new View.OnClickListener() {
//             @Override
//             public void onClick(View v) {
//
//                 // validating if the text field is empty or not.
//                 if (
//                         Susername.getText().toString().isEmpty() &&
//                                 Snama.getText().toString().isEmpty() &&
//                                 Snohp.getText().toString().isEmpty() &&
//                                 Sdom.getText().toString().isEmpty() &&
//                                 Sjalan.getText().toString().isEmpty() &&
//                                 Sinstansi.getText().toString().isEmpty() &&
//                                 Stgl.getText().toString().isEmpty() &&
//                                 Sjam.getText().toString().isEmpty() &&
//                                 Shari.getText().toString().isEmpty() &&
//                                 Sakti.getText().toString().isEmpty() &&
//                                 Snamajumpa.getText().toString().isEmpty() &&
//                                 Snohpjumpa.getText().toString().isEmpty() &&
//                                 Semailjumpa.getText().toString().isEmpty() &&
//                                 Sunitjumpaa.getSelectedItem().toString().isEmpty() &&
//                                 Slokasi.getSelectedItem().toString().isEmpty()) {
//
//                     Toast.makeText(nonkaryawan_in.this, "Please enter both the values", Toast.LENGTH_SHORT).show();
//                     return;
//                 }
//             }
//         });
// ///////////////////////////////////////////////////////////////////////////////
// /*
//         //private void postDataUsingVolley (String username, nama, nohp, dom, jalan, instansi, tgl, jam, hari, akti, namajumpa, nohpjumpa, emailjumpa, unitjumpa, lokasi)
//       //  {
//
//             // url to post our data
//             String url = "https://sbatestapp.000webhost.com/vsa2021/datanonkrywn.php";
//             loadingPB.setVisibility(View.VISIBLE);
//
//             // creating a new variable for our request queue
//           //  RequestQueue queue = Volley.newRequestQueue(nonkaryawan_in.this);
//
// ///////////////////////////////////////////////////////////////////////////////
//
//             // on below line we are calling a string
//             // request method to post the data to our API
//             // in this we are calling a post method.
//       /*      StringRequest request = new StringRequest(Request.Method.POST, url, new com.android.volley.Response.Listener<String>() {
//                 @Override
//                 public void onResponse(String response) {
//                     // inside on response method we are
//                     // hiding our progress bar
//                     // and setting data to edit text as empty
//                     loadingPB.setVisibility(View.GONE);
//                     Susername.setText("");
//                     Snama.setText("");
//                     Snohp.setText("");
//                     Sdom.setText("");
//                     Sjalan.setText("");
//                     Sinstansi.setText("");
//                     Stgl.setText("");
//                     Sjam.setText("");
//                     Shari.setText("");
//                     Sakti.setText("");
//                     Snamajumpa.setText("");
//                     Snohpjumpa.setText("");
//                     Semailjumpa.setText("");
//
//                     // on below line we are displaying a success toast message.
//                     Toast.makeText(nonkaryawan_in.this, "Data added to API", Toast.LENGTH_SHORT).show();
//                     try {
//                         // on below line we are passing our response
//                         // to json object to extract data from it.
//                         JSONObject respObj = new JSONObject(response);
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//                         // below are the strings which we
//                         /* extract from our json object.
//                         String username = respObj.getString("username");
//                         String nama = respObj.getString("nama");
//                         String nohp = respObj.getString("nohp");
//                         String dom = respObj.getString("dom");
//                         String jalan = respObj.getString("jalan");
//                         String instansi = respObj.getString("instansi");
//                         String tgl = respObj.getString("tgl");
//                         String jam = respObj.getString("jam");
//                         String hari = respObj.getString("hari");
//                         String akti = respObj.getString("akti");
//                         String namajumpa = respObj.getString("nama jumpa");
//                         String nohpjumpa = respObj.getString("no hp jumpa");
//                         String emailjumpa = respObj.getString("email jumpa");
//
//
//                         //on below line we are setting this string s to our text view.
// responseTV.setText("Name : " + name + "\n" + "Job : " + job);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // method to handle errors.
                    Toast.makeText(nonkaryawan_in.this, "Fail to get response = " + error, Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() {
                    // below line we are creating a map for
                    // storing our values in key and value pair.
                    Map<String, String> params = new HashMap<String, String>();

                    // on below line we are passing our key
                    // and value pair to our parameters.
                    params.put("username", username);
                    params.put("nama", nama);
                    params.put("nohp", nohp);
                    params.put("dom", dom);
                    params.put("jalan", jalan);
                    params.put("instansi", instansi);
                    params.put("tgl", tgl);
                    params.put("jam", jam);
                    params.put("hari", hari);
                    params.put("akti", akti);
                    params.put("namajum ", namajumpa);
                    params.put("nohpjum ", nohpjumpa);
                    params.put("emailjum ", emailjumpa);
                    params.put("unit", unitjumpa);
                    params.put("lokasi", lokasi);

                    // at last we are
                    // returning our params.
                    return params;
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/x-www-form-urlencoded");
                    return params;
                }
            };
            // below line is to make
            // a json object request.
            queue.add(request);


        }
    }
//
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
/*
terima.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Pindahke();

        if (TextUtils.isEmpty(username)){
            Susername.setError("NIK tidak boleh kosong");
        } else if (TextUtils.isEmpty(nama)){
            Snama.setError("Nama tidak boleh kosong");
        } else if (TextUtils.isEmpty(nohp)){
            Snohp.setError("No HP tidak boleh kosong");
        } else if (TextUtils.isEmpty(dom)){
            Sdom.setError("Alamat tidak boleh kosong");
        } else if (TextUtils.isEmpty(jalan)){
            Sjalan.setError("Riwayat perjalanan tidak boleh kosong");
        } else if (TextUtils.isEmpty(instansi)){
            Sinstansi.setError("Instansi tidak boleh kosong");
        } else if (TextUtils.isEmpty(tgl)){
            Stgl.setError("Tanggal tidak boleh kosong");
        }else if (TextUtils.isEmpty(jam)){
            Sjam.setError("Jam tidak boleh kosong");
        }else if (TextUtils.isEmpty(hari)){
            Shari.setError("Jumlah hari tidak boleh kosong");
        }else if (TextUtils.isEmpty(akti)){
            Sakti.setError("Aktifitas tidak boleh kosong");
        }else if (TextUtils.isEmpty(namajumpa)){
            Snamajumpa.setError("Nama dijumpai tidak boleh kosong");
        }else if (TextUtils.isEmpty(nohpjumpa)){
            Snohpjumpa.setError("No hp dijumpai tidak boleh kosong");
        }else if (TextUtils.isEmpty(emailjumpa)){
            Semailjumpa.setError("Email dijumpai tidak boleh kosong");
        } else {
            addDataToDatabase (username,nama,nohp,jalan,dom,instansi,tgl,jam,hari,akti, namajumpa, nohpjumpa, emailjumpa, unitjumpa,lokasi);

        }

    }
});
    }

    private void addDataToDatabase(String username, String nama, String nohp, String jalan, String dom, String instansi, String tgl, String jam, String hari, String akti, String namajum, String nohpjum, String emailjumpa, String unitjumpa, String lokasi) {
        String url = "https://sbatestapp.000webhostapp.com/vsa2021/tambahnon.php";
        RequestQueue queue = Volley.newRequestQueue(nonkaryawan_in.this);
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("TAG","RESPONSE IS" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(nonkaryawan_in.this, jsonObject.getString("message"),Toast.LENGTH_SHORT).show();
                } catch (JSONException e){
                    e.printStackTrace();
                }
                Susername.setText("");
                Snama.setText("");
                Snohp.setText("");
                Sdom.setText("");
                Sjalan.setText("");
                Sinstansi.setText("");
                Stgl.setText("");
                Sjam.setText("");
                Shari.setText("");
                Sakti.setText("");
                Snamajumpa.setText("");
                Snohpjumpa.setText("");
                Semailjumpa.setText("");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(nonkaryawan_in.this, "Gagal mendapatkan respon =" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
        @Override
        public String getBodyContentType(){
            return "application/x-www-form-urlencoded; charset=UTF-8";
        }
            protected Map<String, String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("username" , username);
                params.put("nama", nama );
                params.put("nohp", nohp);
                params.put("dom", dom );
                params.put("jalan", jalan );
                params.put("instansi",instansi );
                params.put("tgl", tgl );
                params.put("jam",jam );
                params.put("hari",hari );
                params.put("akti", akti);
                params.put("namajum ",namajumpa );
                params.put("nohpjum ", nohpjumpa );
                params.put("emailjum ",emailjumpa );
                params.put("unit",unitjumpa);
                params.put("lokasi", lokasi);
                return params;
            }
 };
       queue.add(request);
    }
    private void Pindahke() {
        Intent pindah = new Intent(nonkaryawan_in.this, Form_kesehatan.class);
        startActivity(pindah);
    }




} */
