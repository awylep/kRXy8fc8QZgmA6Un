package com.awi.appsba.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;

import com.awi.appsba.R;


public class Beranda extends AppCompatActivity {
AppCompatButton tm, krr;
    Animation ttb, btt;
    AppCompatImageView emblem_app;
    AppCompatTextView intro_ap , new_account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda);

        // load animation
        ttb = AnimationUtils.loadAnimation(this, R.anim.ttb);
        btt = AnimationUtils.loadAnimation(this, R.anim.btt);

        intro_ap = (findViewById(R.id.intro_app));
        new_account = (findViewById(R.id.new_account));
        emblem_app = findViewById(R.id.emblem_app);

        tm = (AppCompatButton)findViewById(R.id.btn_tamu);
        krr = (AppCompatButton)findViewById(R.id.btn_kurir);

        //intent
        tm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent direct = new Intent(getBaseContext(), com.awi.appsba.activity.TamuDirect.class);
                startActivity(direct);
            }
        });


        // run animation
        emblem_app.startAnimation(ttb);
        intro_ap.startAnimation(ttb);
        krr.startAnimation(btt);
        tm.startAnimation(btt);
        new_account.startAnimation(btt);

        new_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cbt = new Intent(getBaseContext(), com.awi.appsba.activity.UserData.class);
                startActivity(cbt);
            }
        });

        krr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent krr = new Intent(getBaseContext(), com.awi.appsba.activity.Login_Kurir.class);
                startActivity(krr);
            }
        });



    }



}