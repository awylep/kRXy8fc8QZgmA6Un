package com.awi.appsba.activity;


public class konfigurasi {

    //Dibawah ini merupakan Pengalamatan dimana Lokasi Skrip CRUD PHP disimpan

    public static final String URL_ADD_KRR="http://192.168.100.144/sbaapp/filephp/tambahKurir.php";
    public static final String URL_ADD_KRYWN="http://192.168.100.144/sbaapp/filephp/tambahKrywn.php";
    public static final String URL_ADD_NONKRYWN="http://192.168.100.144/sbaapp/filephp/tambahnonKrywn.php";

    public static final String URL_GET_ALL = "http://192.168.1.12/Android/pegawai/tampilSemuaPgw.php";
    public static final String URL_GET_EMP = "http://192.168.1.12/Android/pegawai/tampilPgw.php?id=";
    public static final String URL_UPDATE_EMP = "http://192.168.1.12/Android/pegawai/updatePgw.php";
    public static final String URL_DELETE_EMP = "http://192.168.1.12/Android/pegawai/hapusPgw.php?id=";

    //Dibawah ini merupakan Kunci yang akan digunakan untuk mengirim permintaan ke Skrip PHP
    //KURIR
    public static final String KEY_KRR_USERNAME = "username";
    public static final String KEY_KRR_NAMA = "name";
    public static final String KEY_KRR_INSTANSI = "instansi";
    public static final String KEY_KRR_TANGGAL = "tanggal";
    public static final String KEY_KRR_JAM = "jam";
    public static final String KEY_KRR_HARI = "hari";
    public static final String KEY_KRR_LAIN = "lain";
    public static final String KEY_KRR_NAMAJUMPA = "nama jumpa";
    public static final String KEY_KRR_NOHPJUMPA = "nohp jumpa";
    public static final String KEY_KRR_EMAILJUMPA = "email jumpa";

    //KARYAWAN
    public static final String KEY_KRYWN_USERNAME = "username";
    public static final String KEY_KRYWN_NAMA = "nama";
    public static final String KEY_KRYWN_INSTANSI = "instansi";
    public static final String KEY_KRYWN_UNIT = "unit";
    public static final String KEY_KRYWN_TGGL = "tggl";
    public static final String KEY_KRYWN_JAM = "jam";
    public static final String KEY_KRYWN_HARI = "hari";
    public static final String KEY_KRYWN_AKTI = "akti";
    public static final String KEY_KRYWN_LOKASI = "lokasi";
    public static final String KEY_KRYWN_NAMAJUMPA = "nama jumpa";
    public static final String KEY_KRYWN_NOHPJUMPA = "nohp jumpa";
    public static final String KEY_KRYWN_EMAILJUMPA = "email jumpa";

    //NON_KARYAWAN
    public static final String KEY_NONKRYWN_USERNAME = "username";
    public static final String KEY_NONKRYWN_NAMA = "nama";
    public static final String KEY_NONKRYWN_NOHP = "nohp";
    public static final String KEY_NONKRYWN_UNIT = "unit";
    public static final String KEY_NONKRYWN_JALAN = "jalan";
    public static final String KEY_NONKRYWN_INSTANSI = "instansi";
    public static final String KEY_NONKRYWN_TGGL = "tggl";
    public static final String KEY_NONKRYWN_JAM = "jam";
    public static final String KEY_NONKRYWN_HARI = "hari";
    public static final String KEY_NONKRYWN_AKTI = "akti";
    public static final String KEY_NONKRYWN_LOKASI = "lokasi";
    public static final String KEY_NONKRYWN_NAMAJUMPA = "nama jumpa";
    public static final String KEY_NONKRYWN_NOHPJUMPA = "nohp jumpa";
    public static final String KEY_NONKRYWN_EMAILJUMPA = "email jumpa";

    //JSON Tags
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_INSTANSI = "instansi";
    public static final String TAG_TANGGAL = "tanggal";
    public static final String TAG_JAM = "jam";
    public static final String TAG_HARI = "hari";
    public static final String TAG_LAIN = "lain";
    public static final String TAG_NAMAJUMPA = "nama jumpa";
    public static final String TAG_NOHPJUMPA = "nohp jumpa";
    public static final String TAG_EMAILJUMPA = "email jumpa";

    public static final String KRR_USERNAME = "krr_username";
    public static final String KRYWN_USERNAME = "krywn_username";
    public static final String NONKRYWN_USERNAME = "nonkrywn_username";
}