package com.awi.appsba.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.awi.appsba.R;

public class UserData extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);







    }
}

