package com.awi.appsba.api;

import com.awi.appsba.model.ResponsModelnon;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiRequestBiodatanon {
    @FormUrlEncoded
    @POST("datanonkrywn.php")
    Call<ResponsModelnon> sendBiodatanonkrywn (@Field("username") String username,
                                       @Field("nama") String nama,
                                       @Field("instansi") String instansi,
                                       @Field("no hp") String nohp,
                                       @Field("dom") String dom,
                                       @Field("jalan") String jalan,
                                       @Field("unit") String unit,
                                       @Field("tgl") String tgl,
                                       @Field("jam") String jam,
                                       @Field("hari") String hari,
                                       @Field("akti") String akti,
                                       @Field("lokasi") String lokasi,
                                       @Field("nama jumpa") String namajumpa,
                                       @Field("nohp jumpa") String nohpjumpa,
                                       @Field("email jumpa") String emailjumpa,
                                       @Field("unit jumpa") String unitjumpa);
    @GET("read.php")
    Call<ResponsModelnon> getBiodatanonkrywn();

    @FormUrlEncoded
    @POST("update.php")
    Call<ResponsModelnon> updateDatanonkrywn (@Field("username") String username,
                                      @Field("nama") String nama,
                                      @Field("instansi") String instansi,
                                      @Field("no hp") String nohp,
                                      @Field("dom") String dom,
                                      @Field("jalan") String jalan,
                                      @Field("unit") String unit,
                                      @Field("tgl") String tgl,
                                      @Field("jam") String jam,
                                      @Field("hari") String hari,
                                      @Field("akti") String akti,
                                      @Field("lokasi") String lokasi,
                                      @Field("nama jumpa") String namajumpa,
                                      @Field("nohp jumpa") String nohpjumpa,
                                      @Field("email jumpa") String emailjumpa,
                                      @Field("unit jumpa") String unitjumpa);

    @FormUrlEncoded
    @POST("delete.php")
    Call<ResponsModelnon> deleteDatanonkrywn (@Field("username") String username);
}
