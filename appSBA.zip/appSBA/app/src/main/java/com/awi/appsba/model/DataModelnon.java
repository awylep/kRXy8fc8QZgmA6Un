package com.awi.appsba.model;

public class DataModelnon {
    /////////////////////////////////////NON-KRYWN//////////////////////////////////////////
   String nama, username, nohp, dom, jalan, instansi, tgl, jam, hari, akti, namajumpa, nohpjumpa, emailjumpa, lokasi, unitjumpa;
    ///////////////////////////////////////////////
    public String getUsername(){
        return  username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    ////////////////////////////////////////////////
    public String getNama(){
        return nama;
    }

    public void setNama(String nama){
        this.nama = nama;
    }
    ////////////////////////////////////////////////
    public String getInstansi(){
        return instansi;
    }

    public void setInstansi(String instansi){
        this.instansi = instansi;
    }
    ////////////////////////////////////////////////
    public String getNohp(){
        return nohp;
    }

    public void setNohp (String nohp){
        this.nohp = nohp;
    }
    ////////////////////////////////////////////////
    public String getJalan(){
        return jalan;
    }

    public void setJalan (String jalan){
        this.jalan = jalan;
    }
    ////////////////////////////////////////////////
    public String getDom (){
        return dom;
    }

    public void setDom(String dom){
        this.dom = dom;
    }
    ////////////////////////////////////////////////
    public String getTgl(){
        return tgl;
    }

    public void setTgl(String tgl){
        this.tgl = tgl;
    }
    ////////////////////////////////////////////////
    public String getJam(){
        return jam;
    }

    public void setJam(String jam){
        this.jam = jam;
    }
    ////////////////////////////////////////////////
    public String getHari(){
        return hari;
    }

    public void setHari(String hari){
        this.hari = hari;
    }
    ///////////////////////////////////////////////
    public String getAkti() {
        return akti;
    }

    public void setAkti(String akti) {
        this.akti = akti;
    }
    ///////////////////////////////////////////////
    public String getNamajumpa() {
        return namajumpa;
    }

    public void setNamajumpa(String namajumpa) {
        this.namajumpa = namajumpa;
    }
    ///////////////////////////////////////////////
    public String getNohpjumpa() {
        return nohpjumpa;
    }

    public void setNohpjumpa(String nohpjumpa) {
        this.nohpjumpa = nohpjumpa;
    }
    ///////////////////////////////////////////////
    public String getEmailjumpa() {
        return emailjumpa;
    }

    public void setEmailjumpa(String emailjumpa) {
        this.emailjumpa = emailjumpa;
    }
    ///////////////////////////////////////////////
    public String getUnitjumpa() {
        return unitjumpa;
    }

    public void setUnitjumpa(String unitjumpa) {
        this.unitjumpa = unitjumpa;
    }
    ///////////////////////////////////////////////
    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }
////////////////////////////////////////////////

}
