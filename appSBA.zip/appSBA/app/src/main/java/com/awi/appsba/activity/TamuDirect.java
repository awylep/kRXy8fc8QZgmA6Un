package com.awi.appsba.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.awi.appsba.R;

public class TamuDirect extends AppCompatActivity {

    AppCompatButton btnkr, btnnon;
    Animation ttb, btt;
    TextView jns;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamu_direct);

        btnkr = (findViewById(R.id.btnjnskrywn));
        btnnon = (findViewById(R.id.btnjenisnon));
        jns = (findViewById(R.id.jnskunjungan));

// load animation
        ttb = AnimationUtils.loadAnimation(this, R.anim.ttb);
        btt = AnimationUtils.loadAnimation(this, R.anim.btt);
// run animation
        jns.startAnimation(ttb);
        btnnon.startAnimation(btt);
        btnkr.startAnimation(btt);
        btnkr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnkrr = new Intent (getBaseContext(),form_krywn_in.class);
                startActivity(btnkrr);
            }
        });

        btnnon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnnon = new Intent(getBaseContext(), com.awi.appsba.activity.nonkaryawan_in.class);
                startActivity(btnnon);
            }
        });
    }
}