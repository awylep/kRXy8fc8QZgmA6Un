package com.awi.appsba.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.awi.appsba.R;
import com.awi.appsba.DATABASE.DataHelper;
import com.awi.appsba.api.ApiRequestBiodatakrr;
import com.awi.appsba.model.ResponsModelkrr;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class FormKurir extends AppCompatActivity {
    String[]  lokasi3 = {"PILIH LOKASI", "BP ANCOL", "BP BALARAJA", "BP BANDUNG", "BP BEKASI", "BP CIANJUR", "BP CIBITUNG", "BP CILACAP", "BP CILEGON", "BP CIUJUNG", "BP CIWANDAN", "BP DADAP", "BP DAMOCI", "BP GEDANGAN", "BP KANCI", "BP KARAWANG", "BP KEDIRI", "BP KEMBANGAN", "BP LEGOK", "BP KLAPANUNGGAL", "BP PANDAAN", "BP PONDOK INDAH", "BP PULOGADUNG", "BP RUNGKUT", "CILACAP", "BP SEMARANG", "BP SENTUL", "BP SERPONG", "BP TANJUNGSARI", "BP THAMRIN 9", "BP YOGYAKARTA", "BP Karangkandri", "BP Kalibaru", "BP Jawa 9-10", "CILACAP LOGISTICS", "COP Cawang Bypass", "COP Bambu Apus", "GUDANG BOGOR", "GUDANG CIKANDE", "GUDANG CIKEMBAR", "GUDANG CIREBON", "GUDANG LEMPUYANGAN", "GUDANG SOLO", "GUDANG SUNDA KELAPA", "JELADRI", "LHOKNGA", "LHOKNGA LOGISTICS", "MALOKO", "NAROGONG PLANT", "NAROGONG LOGISTICS", "TALAVERA", "TERMINAL BATAM", "TERMINAL BELAWAN", "TERMINAL DUMAI", "TERMINAL LAMPUNG", "TERMINAL LHOKSEUMAWE", "TERMINAL PALEMBANG WH", "TERMINAL PONTIANAK", "TUBAN", "TUBAN LOGISTICS", "GEDANGAN SURABAYA"};
   // String JSON_STRING = "{\"username\":{\"nama\":\"instansi\":{\"tanggal\":{\"jam\":{\"hari\":{\"akti\":{\"namajum\":{\"nohpjum\":{\"emailjum\",\"09021998\":{\"awi\":{\"maxim\":{\"10-11-2021\":{\"12:12\":{\"13\":{\"antar barang\":{\"rizki\":{\"085943631354\":{\"rizkimunandarh@gmail.com\":65000}}";
  //  private static final String HI ="https://sbatestapp.000webhostapp.com/vsa2021/insertdata.php" ;

    EditText Tanggal, Jam, Hari, Lain, Namajumpa, Nohpjumpa, Emailjumpa;
    RadioButton rbantar, rblain;
    Spinner spin,unitjumpa;
    Button dterima;
    TextView Signedinusername, Signedinnama, Signedininstansi;
    String username1,nama1,instansi1,tanggal1,jam1,hari1,akti1,namajum,nohpjum,emailjum, unitjum, lokas;
    DataHelper dbHelper;

    SharedPreferences mPreferences;
    SharedPreferences.Editor preferencesEditor;
    String sharedprofFile = "com.awi.appsba.Activity.Login_Kurir";

   // RequestQueue requestQueue;
   ProgressDialog pdDialog;
   // private static String URL_REGIST = "https://sbatestapp.000webhostapp.com/vsa2021/register.php";




    protected void onCreate(Bundle savedInstanceState, ApiRequestBiodatakrr api) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_kurir);


        pdDialog = new ProgressDialog(FormKurir.this);
        pdDialog.setTitle("Inserting please wait...");
        pdDialog.setCancelable(false);
        setContentView(R.layout.activity_form_kurir);
        dbHelper = new DataHelper(this);

        Tanggal = (EditText) findViewById(R.id.tgl);
        Jam = (EditText) findViewById(R.id.jam);
        Hari = (EditText) findViewById(R.id.hari);
        rbantar = (RadioButton) findViewById(R.id.RBantar);
        rblain = (RadioButton) findViewById(R.id.RBlain);
        Lain = (EditText) findViewById(R.id.edlain);
        spin = (Spinner) findViewById(R.id.spinner3);
        unitjumpa = (Spinner) findViewById(R.id.spinner1);
        Namajumpa = (EditText) findViewById(R.id.ed_namajumpa);
        Nohpjumpa = (EditText) findViewById(R.id.ed_nohpjumpa);
        Emailjumpa = (EditText) findViewById(R.id.ed_emailjumpa);


        mPreferences = getSharedPreferences(sharedprofFile, MODE_PRIVATE);
        preferencesEditor = mPreferences.edit();
        Signedinusername = (TextView) findViewById(R.id.nikkurir);
        Signedinnama = (TextView) findViewById(R.id.namakurir);
        Signedininstansi = (TextView) findViewById(R.id.instkurir);

        username1 = mPreferences.getString("SignedInUsername", "null");
        nama1 = mPreferences.getString("SignedInNama", "null");
        instansi1 = mPreferences.getString("SignedInInstasi", "null");

        Signedinusername.setText(username1);
        Signedinnama.setText(nama1);
        Signedininstansi.setText(instansi1);

////////////////////////////////////JSON///////////////////////////////////////
        Intent data = getIntent();
        final String usernamedata = data.getStringExtra("username");
        if (usernamedata != null) {
            dterima.setVisibility(View.GONE);
            Signedinnama.setText(data.getStringExtra("nama"));
            Signedinusername.setText(data.getStringExtra("username"));
            Signedininstansi.setText(data.getStringExtra("instansi"));
            Tanggal.setText(data.getStringExtra("tggl"));
            Jam.setText(data.getStringExtra("jam"));
            Hari.setText(data.getStringExtra("hari"));
            Namajumpa.setText(data.getStringExtra("nama jumpa"));
            Nohpjumpa.setText(data.getStringExtra("no hp jumpa"));
            Emailjumpa.setText(data.getStringExtra("email jumpa"));
        }
        dterima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String snama = Signedinnama.getText().toString();
                String susername = Signedinusername.getText().toString();
                String sinstansi = Signedininstansi.getText().toString();
                String stggl = Tanggal.getText().toString();
                String sjam = Jam.getText().toString();
                String shari = Hari.getText().toString();
                String snamajumpa = Namajumpa.getText().toString();
                String snohpjumpa = Nohpjumpa.getText().toString();
                String semailjumpa = Emailjumpa.getText().toString();

                Call<ResponsModelkrr> sendbio = api.sendBiodatakrr(snama, susername, sinstansi, stggl, sjam, shari, snamajumpa, snohpjumpa, semailjumpa);
                sendbio.enqueue(new Callback<ResponsModelkrr>() {
                    @Override
                    public void onResponse(Call<ResponsModelkrr> call, Response<ResponsModelkrr> response) {
                        Log.d("RETRO", "response : " + response.body().toString());
                        String username = response.body().getUsername();

                        if (username.equals("1")) {
                            Toast.makeText(FormKurir.this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(FormKurir.this, "Data Error tidak berhasil disimpan", Toast.LENGTH_SHORT).show();

                        }
                    }

                    @Override
                    public void onFailure(Call<ResponsModelkrr> call, Throwable t) {
                        Log.d("RETRO", "Falure : " + "Gagal Mengirim Request");
                    }
                });

            }
        });
    }
}
           /*

        try {
            // get JSONObject from JSON file
            JSONObject obj = new JSONObject(JSON_STRING);
            // fetch JSONObject named employee
            JSONObject employee = obj.getJSONObject("kurir");
            // get data
            Signedinusername.setText("Username : "+username1);
            Signedinnama.setText("Nama :" +nama1);
            Signedininstansi.setText("Instansi :" +instansi1);
            Tanggal.setText("Tanggal :" +tanggal1);

            Jam.setText("Jam :" +jam1);
            Hari.setText("Hari :"+hari1);
            Lain.setText("Aktifitas :" +akti1);
            Namajumpa.setText("Nama Dijumpa :"+namajum);
            Nohpjumpa.setText("No HP Dijumpai :"+nohpjum);
            Emailjumpa.setText("Email Dijumpai :"+emailjum);
        } catch (JSONException e) {
            e.printStackTrace();
        }
////////////////////////////////////JSON///////////////////////////////////////

    dterima.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            adddata();
            spin.toString();

            pindah();
        }
    });

    }

    private void pindah() {
        Intent pnd = new Intent(getBaseContext(),Form_kesehatan.class);
        startActivity(pnd);
    }

    private void adddata() {
        final String username = Signedinusername.getText().toString().trim();
        final String nama = Signedinnama.getText().toString().trim();
        final String instansi = Signedininstansi.getText().toString().trim();
        final String tanggal = Tanggal.getText().toString().trim();
        final String jam = Jam.getText().toString().trim();
        final String hari = Hari.getText().toString().trim();
        final String lain = Lain.getText().toString().trim();
        final String namajumpa = Namajumpa.getText().toString().trim();
        final String nohpjumpa= Nohpjumpa.getText().toString().trim();
        final String emailjumpa = Emailjumpa.getText().toString().trim();

        final String unitjum = unitjumpa.getSelectedItem().toString();
        final String lokas = spin.getSelectedItem().toString();

       StringRequest stringRequest=new StringRequest(Request.Method.POST, HI, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            protected Map<String, String> getParams()  {
                Map<String,String>parms=new HashMap<String, String>();
                parms.put("username", username);
                parms.put("nama",nama);
                parms.put("instansi",instansi);
                parms.put("tanggal",tanggal);
                parms.put("jam",jam);
                parms.put("hari",hari);
                parms.put("lain",lain);
                parms.put("namajumpa", namajumpa);
                parms.put("nohpjumpa", nohpjumpa);
                parms.put("emailjumpa", emailjumpa);
                parms.put("unitjumpa", unitjum);
                parms.put("lokasi",lokas);

                return parms;
            }
    };
        RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }




    } */
