package com.awi.appsba.api;

import retrofit2.Retrofit;

public class UtilsApi {

    private static Retrofit retrofit;
    public static final String BASE_URL_API = "http://192.168.100.144/sbaapp/apis/";

    // Mendeklarasikan Interface BaseApiService
    public static BaseApiService getAPIService() {
        return RetrofitClient.getClient(BASE_URL_API).create(BaseApiService.class);
    }

}
