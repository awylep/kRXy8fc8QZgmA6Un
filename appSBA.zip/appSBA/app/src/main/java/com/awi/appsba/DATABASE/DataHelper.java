package com.awi.appsba.DATABASE;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "visitordb.db";
    private static final int DATABASE_VERSION = 1;

    public DataHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE datakrywn (username int(50) NOT NULL PRIMARY KEY, nama text NOT NULL, instansi text NOT NULL,unit text NOT NULL,tggl text NOT NULL,jam text NOT NULL,hari text NOT NULL,akti text NOT NULL,lokasi text NOT NULL,namajumpa text NOT NULL,nohpjumpa text NOT NULL,emailjumpa text NOT NULL,unitjumpatext NOT NULL)");
        db.execSQL("INSERT INTO datakrywn (username, nama, instansi, unit, tggl, jam, hari, akti, lokasi, namajumpa, nohpjumpa, emailjumpa, unitjumpa) VALUES (1106070902980006, 'Rizki HM', 'IT', 'IT', '09/02/2021', '09:00', '5', 'antar barang', 'LHOKNGA', 'amrullah', '08xxxxxxx', 'amrullah@test.com', 'IT')");


        db.execSQL("CREATE TABLE datanonkrywn (username int(50) NOT NULL PRIMARY KEY, nama text NOT NULL, nohp text NOT NULL,unit text NOT NULL,jalan text NOT NULL,instansi text NOT NULL,tggl text NOT NULL,jam text NOT NULL,hari text NOT NULL,akti text NOT NULL,lokasi text NOT NULL,namajumpa text NOT NULL,nohpjumpa text NOT NULL,emailjumpa text NOT NULL,unitjumpatext NOT NULL)");
        db.execSQL("INSERT INTO datanonkrywn (username, nama, nohp, unit, jalan, instansi, tggl, jam, hari, akti, lokasi, namajumpa, nohpjumpa, emailjumpa, unitjumpa) VALUES (1106070902980006, 'Rizki HM', '0877xxxx', 'IT', 'TIdak Ada', 'IT', '09/02/2021', '09:00', '5', 'antar barang', 'LHOKNGA', 'amrullah', '08xxxxxxx', 'amrullah@test.com', 'IT')");

        db.execSQL("CREATE TABLE datakurir (username int(50) NOT NULL PRIMARY KEY, nama text NOT NULL, instansi text NOT NULL,tanggal text NOT NULL,jam text NOT NULL,hari text NOT NULL,akti text NOT NULL,namajum text NOT NULL,nohpjum text NOT NULL,emailjum text NOT NULL,unitjum text NOT NULL,lokasi text NOT NULL)");
        db.execSQL("INSERT INTO datakurir (username,nama,instansi,tanggal,jam,hari,akti,namajum,nohpjum,emailjum, unitjum, lokasi) VALUES (1106070902980006, 'Rizki HM', 'IT', '09/02/2021', '09:00', '5', 'antar barang', 'amrullah', '08xxxxxxx', 'amrullah@test.com', 'IT', 'LHOKNGA')");


        db.execSQL("CREATE TABLE user (username int(50) NOT NULL PRIMARY KEY, nama text NOT NULL, instansi text NOT NULL, alamat text NOT NULL, email text NOT NULL, password text NOT NULL)");
        db.execSQL("INSERT INTO user (username, nama, instansi, alamat, email, password) VALUES (1106070902980006, 'Rizki HM', 'GOFOOD', 'lamsidaya', 'teset@test.com', 'test123')");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP  TABLE datakrywn");
        db.execSQL("DROP TABLE datanonkrywn");
        db.execSQL("DROP TABLE datakurir");
        db.execSQL("DROP TABLE user");
    }
}
