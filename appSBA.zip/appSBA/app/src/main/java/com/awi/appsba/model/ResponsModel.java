package com.awi.appsba.model;

import java.util.List;

public class ResponsModel {
    String username, nama, instansi, unit, tggl, jam, hari, akti, namajumpa, nohpjumpa, emailjumpa, unitjumpa, lokasi;

    List<DataModel> result;

    public List<DataModel> getResult() {
        return result;
    }
    public void setResult(List<DataModel> result) {
        this.result = result;
    }
    public String getUsername(){
        return  username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    ////////////////////////////////////////////////
    public String getNama(){
        return nama;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    ////////////////////////////////////////////////
    public String getInstansi(){
        return instansi;
    }
    public void setInstansi(String instansi){
        this.instansi = instansi;
    }
    ////////////////////////////////////////////////
    public String getUnit (){
        return unit;
    }
    public void setUnit(String unit){
        this.unit = unit;
    }
    ////////////////////////////////////////////////
    public String getTggl(){
        return tggl;
    }
    public void setTgl(String tggl){
        this.tggl = tggl;
    }
    ////////////////////////////////////////////////
    public String getJam(){
        return jam;
    }
    public void setJam(String jam){
        this.jam = jam;
    }
    ////////////////////////////////////////////////
    public String getHari(){
        return hari;
    }
    public void setHari(String hari){
        this.hari = hari;
    }
    ///////////////////////////////////////////////
    public String getAkti() {
        return akti;
    }
    public void setAkti(String akti) {
        this.akti = akti;
    }
    ///////////////////////////////////////////////
    public String getNamajumpa() {
        return namajumpa;
    }
    public void setNamajumpa(String namajumpa) {
        this.namajumpa = namajumpa;
    }
    ///////////////////////////////////////////////
    public String getNohpjumpa() {
        return nohpjumpa;
    }
    public void setNohpjumpa(String nohpjumpa) {
        this.nohpjumpa = nohpjumpa;
    }
    ///////////////////////////////////////////////
    public String getEmailjumpa() {
        return emailjumpa;
    }
    public void setEmailjumpa(String emailjumpa) {
        this.emailjumpa = emailjumpa;
    }
    ///////////////////////////////////////////////
    public String getUnitjumpa() {
        return unitjumpa;
    }
    public void setUnitjumpa(String unitjumpa) {
        this.unitjumpa = unitjumpa;
    }
    ///////////////////////////////////////////////
    public String getLokasi() {
        return lokasi;
    }
    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }
}