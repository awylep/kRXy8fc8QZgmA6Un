package com.awi.appsba.adapterLogin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.awi.appsba.activity.FormKurir;
import com.awi.appsba.activity.Login_Kurir;

import java.util.HashMap;

public class SessionManager {
    public static final String CEK_LOGIN = "IsLogin";

    // Shared preferences file name
    public static final String PREF_ID = "AMBIL_ID";
    public static final String PREF_NAME = "PREF_NAME";
    private static final String CEK_SUDAH_LOGIN = "sessionLogin";
    private static final String CEK_HASIL_NOTIF = "sessionNotif";
    private static final String CEK_VIEW_KONTAK = "sessionKontak";
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Context mContext;

    public static String getCekSudahLogin() {
        return CEK_SUDAH_LOGIN;
    }

    // context
    public SessionManager(Context context) {
        this.mContext = context;
        pref = mContext.getSharedPreferences(PREF_NAME, 0);
        editor = pref.edit();
    }


    // session login
    public boolean sessionLogin() {
        return pref.getBoolean(CEK_SUDAH_LOGIN, false);
    }

    public void setSudahLogin(boolean sudahLogin, String[] data) {
        editor.putBoolean(CEK_SUDAH_LOGIN, sudahLogin);

        //Data User
        editor.putString("username ", data[0]);
        editor.putString("nama", data[1]);
        editor.commit();
    }

    public String getID() {
        return pref.getString("username", "-");
    }

    public String getNama() {
        return pref.getString("nama", "-");
    }



    // ini method khusus pemanggilan button logout
    // karena logout tidak memerlukan data user;
    public void setSudahLogin(boolean sudahLogin) {
        editor.putBoolean(CEK_SUDAH_LOGIN, sudahLogin);
        editor.commit();
    }


}
