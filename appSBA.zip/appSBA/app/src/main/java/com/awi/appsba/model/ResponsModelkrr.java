package com.awi.appsba.model;

import java.util.List;

public class ResponsModelkrr {
    String username,nama,instansi,tanggal,jam,hari,akti,namajum,nohpjum,emailjum, unitjum, lokasi;
    List<DataModelkrr> result;

    public List<DataModelkrr> getResult() {
        return result;
    }

    public void setResult(List<DataModelkrr> result) {
        this.result = result;
    }

    ///////////////////////////////////////////////
    public String getUsername(){
        return  username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    ////////////////////////////////////////////////
    public String getNama(){
        return nama;
    }

    public void setNama(String nama){
        this.nama = nama;
    }
    ////////////////////////////////////////////////
    public String getInstansi(){
        return instansi;
    }

    public void setInstansi(String instansi){
        this.instansi = instansi;
    }
    ////////////////////////////////////////////////
    public String getTanggal(){
        return tanggal;
    }

    public void setTanggal (String tanggal){
        this.tanggal = tanggal ;
    }
    ////////////////////////////////////////////////
    public String getJam(){
        return jam;
    }

    public void setJam(String jam){
        this.jam = jam;
    }
    ////////////////////////////////////////////////
    public String getHari(){
        return hari;
    }

    public void setHari(String hari){
        this.hari = hari;
    }
    ///////////////////////////////////////////////
    public String getAkti() {
        return akti;
    }

    public void setAkti(String akti) {
        this.akti = akti;
    }
    ///////////////////////////////////////////////
    public String getNamajum () {
        return namajum ;
    }

    public void setNamajum (String namajum ) {
        this.namajum  = namajum ;
    }
    ///////////////////////////////////////////////
    public String getNohpjum() {
        return nohpjum;
    }

    public void setNohpjum(String nohpjum) {
        this.nohpjum = nohpjum;
    }
    ///////////////////////////////////////////////
    public String getEmailjum() {
        return emailjum;
    }

    public void setEmailjum(String emailjum) {
        this.emailjum = emailjum;
    }
    ///////////////////////////////////////////////
    public String getUnitjum() {
        return unitjum;
    }

    public void setUnitjum(String unitjum) {
        this.unitjum = unitjum;
    }
    ///////////////////////////////////////////////
    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }
////////////////////////////////////////////////
}
