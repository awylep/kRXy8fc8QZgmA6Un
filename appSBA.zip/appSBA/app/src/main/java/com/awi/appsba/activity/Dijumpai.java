package com.awi.appsba.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.awi.appsba.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Dijumpai extends AppCompatActivity   {
    String[] lokasi = {"PILIH UNIT", "AFR/Nathabumi", "Distribusi", "EVE", "GA & Comrel", "HO", "Information Technology", "Kontruksi", "Maintenance", "OHS", "Packing Plant", "Production", "Quarry", "Security", "Supply Chain", "Technical"};
    EditText namajumpa, nohpjumpa, emailjumpa;
    String ServerURL = "https://sbatestapp.000webhostapp.com/get_data.php";
    Spinner unit;
    Button lanjut;
    String TempNama, TempNohp, TempEmail, TempUnit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dijumpai);

        namajumpa = (EditText) findViewById(R.id.ed_namajumpa);
        nohpjumpa = (EditText) findViewById(R.id.ed_nohpjumpa);
        emailjumpa = (EditText) findViewById(R.id.ed_emailjumpa);
        unit = (Spinner) findViewById(R.id.spinner1);
        lanjut = (Button) findViewById(R.id.ajukanjumpa);

     /*   lanjut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetData();
                InsertData(TempNama,TempEmail,TempNohp,TempUnit);
            }
        });


        //Deklarasi combobox
        Spinner unit = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lokasi);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unit.setAdapter(adapter);
        unit.setOnItemSelectedListener(this);


    }

    private String InsertData(final String tempNama, final String tempEmail, final String tempNohp, final String tempUnit) {
    String NamaHolder = tempNama;
    String EmailHolder = tempEmail;
    String NohpHolder = tempNohp;
    String UnitHolder = tempUnit;
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

        nameValuePairs.add(new BasicNameValuePair("nama",NamaHolder));
        nameValuePairs.add(new BasicNameValuePair("email",EmailHolder));
        nameValuePairs.add(new BasicNameValuePair("nohp",NohpHolder));
        nameValuePairs.add(new BasicNameValuePair("unit",UnitHolder));
        try {
            HttpClient httpClient = new DefaultHttpClient();

            HttpPost httpPost = new HttpPost(ServerURL);

            httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

            HttpResponse httpResponse = httpClient.execute(httpPost);

            HttpEntity httpEntity = httpResponse.getEntity();


        } catch (ClientProtocolException e) {

        } catch (IOException e) {

        }
        return "Data Inserted Successfully";

    }

    private void GetData() {
        TempNama = namajumpa.getText().toString();
        TempNohp = nohpjumpa.getText().toString();
        TempEmail = emailjumpa.getText().toString();
        TempUnit = unit.getPrompt().toString();
    }


    //Bikin Toast muncul
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        Toast.makeText(getApplicationContext(), "PILIH UNIT: " + lokasi[position], Toast.LENGTH_SHORT).show();


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        unit.setPrompt("PILIH UNIT");
    }


    public void lanjutkan(View view) {
        Intent i = new Intent(getBaseContext(), com.awi.myapplication.Activity.Form_kesehatan.class);
        startActivity(i);
    }
} */
    }
}