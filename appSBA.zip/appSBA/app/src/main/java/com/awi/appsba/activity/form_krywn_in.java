package com.awi.appsba.activity;


import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.awi.appsba.R;
import com.awi.appsba.DATABASE.DataHelper;
import com.awi.appsba.api.ApiRequestBiodata;
import com.awi.appsba.model.ResponsModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class form_krywn_in extends AppCompatActivity {

    EditText username, nama, unit, tggl, jam, hari, akti, namajumpa, nohpjumpa, emailjumpa;
    RadioGroup rg;
    Button btnterima;
    String lokasi_list, unit_list;
    Spinner lokasi, unitjumpa;
    // String namakrywn, usernamekrywn, nohpkrywn, unitkrywn, tgglkrywn, jamkrywn, harikrywn, aktifitaskrywn, dnamajumpa, dnohpjumpa, demailjumpa, dunitjumpa, dlokasi;

    private TextView responseTV;
    ProgressDialog pd;

    protected Cursor cursor;
    DataHelper dbHelper;

    protected void onCreate(Bundle savedInstanceState, ApiRequestBiodata api) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_form_krywn_in);
        dbHelper = new DataHelper(this);

        nama = findViewById(R.id.ed_namakar);
        username = findViewById(R.id.ed_nikkar);
        unit = findViewById(R.id.unitkar);
        tggl = findViewById(R.id.tglkar);
        jam = findViewById(R.id.jamkar);
        hari = findViewById(R.id.harikar);
        akti = findViewById(R.id.edlainkar);
        rg = findViewById(R.id.rgkar);
        namajumpa = findViewById(R.id.ed_namajumpakar);
        nohpjumpa = findViewById(R.id.ed_nohpjumpakar);
        emailjumpa = findViewById(R.id.ed_emailjumpakar);
        lokasi = findViewById(R.id.spinner4kar);
        unitjumpa = findViewById(R.id.spinner1kar);
        btnterima = findViewById(R.id.ajukanjumpa);

        responseTV = findViewById(R.id.idTVResponse);


        Intent data = getIntent();
        final String iddata = data.getStringExtra("username");
        if (iddata != null) {
            btnterima.setVisibility(View.GONE);
            nama.setText(data.getStringExtra("nama"));
            username.setText(data.getStringExtra("username"));
            unit.setText(data.getStringExtra("unit"));
            tggl.setText(data.getStringExtra("tggl"));
            jam.setText(data.getStringExtra("jam"));
            hari.setText(data.getStringExtra("hari"));
            akti.setText(data.getStringExtra("akti"));
            namajumpa.setText(data.getStringExtra("nama jumpa"));
            nohpjumpa.setText(data.getStringExtra("no hp jumpa"));
            emailjumpa.setText(data.getStringExtra("email jumpa"));
        }

        pd = new ProgressDialog(this);

        btnterima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pd.setMessage("send data ... ");
                pd.setCancelable(false);
                pd.show();
                String snama = nama.getText().toString();
                String susername = username.getText().toString();
                String sunit = unit.getText().toString();
                String stggl = tggl.getText().toString();
                String sjam = jam.getText().toString();
                String shari = hari.getText().toString();
                String sakti = akti.getText().toString();
                String snamajumpa = namajumpa.getText().toString();
                String snohpjumpa = nohpjumpa.getText().toString();
                String semailjumpa = emailjumpa.getText().toString();

                Call<ResponsModel> sendbio = api.sendBiodata(snama, susername, sunit, stggl, sjam, shari, sakti, snamajumpa, snohpjumpa, semailjumpa);
                sendbio.enqueue(new Callback<ResponsModel>() {
                    @Override
                    public void onResponse(Call<ResponsModel> call, Response<ResponsModel> response) {
                        pd.hide();
                        Log.d("RETRO", "response : " + response.body().toString());
                        String username = response.body().getUsername();

                        if (username.equals("1")) {
                            Toast.makeText(form_krywn_in.this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(form_krywn_in.this, "Data Error tidak berhasil disimpan", Toast.LENGTH_SHORT).show();

                        }
                    }


                    @Override
                    public void onFailure(Call<ResponsModel> call, Throwable t) {
                        pd.hide();
                        Log.d("RETRO", "Falure : " + "Gagal Mengirim Request");
                    }
                });

            }
        });
    }
}
              //  SQLiteDatabase db = dbHelper.getWritableDatabase();
         //   db.execSQL("insert into datakrywn (username, nama, instansi, unit, tggl, jam, hari, akti, lokasi, namajumpa, nohpjumpa, emailjumpa, unitjumpa) values ('"+
                     /*       username.getText().toString() + "','" +
                            nama.getText().toString() + "','" +
                            instansi.getText().toString() + "','" +
                            unit.getText().toString() + "','" +
                            tggl.getText().toString() + "','" +
                            jam.getText().toString() + "','" +
                            hari.getText().toString() + "','" +
                            akti.getText().toString() + "','" +
                            lokasi.getSelectedItem().toString() + "','" +
                            namajumpa.getText().toString() + "','" +
                            nohpjumpa.getText().toString() + "','" +
                            emailjumpa.getText().toString() + "','" +
                            unitjumpa.getSelectedItem().toString() + "');");


                    Toast.makeText(getApplicationContext(), "Berhasil" ,
                    Toast.LENGTH_LONG).show();
            finish();
        });


        String[] lokasi_list = getResources().getStringArray(R.array.lokasi_list);
        ArrayAdapter<String> adaapter = new ArrayAdapter<>(this, R.layout.spinloka, R.id.txspinloka, lokasi_list);
        lokasi.setAdapter(adaapter);

        String[] unit_list = getResources().getStringArray(R.array.unit_list);
        ArrayAdapter<String> adapterr = new ArrayAdapter<>(this, R.layout.spinloka, R.id.txspinunit, unit_list);
        unitjumpa.setAdapter(adapterr);

    }
}*/


