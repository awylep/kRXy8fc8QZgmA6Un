package com.awi.appsba.activity;


import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.awi.appsba.R;
import com.awi.appsba.adapterLogin.LoginDataBaseAdapter;
import com.awi.appsba.adapterLogin.SessionManager;
import com.awi.appsba.api.BaseApiService;
import com.awi.appsba.api.UtilsApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;

public class Login_Kurir extends AppCompatActivity {
    //private static final String LG = "http://192.168.100.144/sbaapp/apis/login.php";


    private EditText username ,password;
    private Button btnmasuk;
    private TextView txbuatakun;

    ProgressDialog progress;
    Context mContext;
    BaseApiService mApiService;
    TextView txm;
    SessionManager sesion;

    Animation ttb, btt;

  //  LoginDataBaseAdapter loginDataBaseAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_kurir);

        txm = (TextView) findViewById(R.id.txmasuk);

        mContext = this;    // .. <- class ini
        mApiService = UtilsApi.getAPIService();  // panggil apihelper

        sesion = new SessionManager(getApplicationContext());  //sessino manager

        // init
        username = findViewById(R.id.txUsername);
        password = findViewById(R.id.txPass);
        btnmasuk = findViewById(R.id.bmasuk);
        txbuatakun = findViewById(R.id.blumpnyid);

        // create a instance of SQLite Database
        //  loginDataBaseAdapter = new LoginDataBaseAdapter(this);
        //   loginDataBaseAdapter = loginDataBaseAdapter.open();

/////////////////////////////////////// load animation ///////////////////////////////////////

        ttb = AnimationUtils.loadAnimation(this, R.anim.ttb);
        btt = AnimationUtils.loadAnimation(this, R.anim.btt);

        // run animation
        txm.startAnimation(ttb);
        username.startAnimation(btt);
        password.startAnimation(btt);
        btnmasuk.startAnimation(btt);
        txbuatakun.startAnimation(btt);

//////////////////////////////////////////////////////////////////////////////////////////////

        // Adding click listener to register button.
        txbuatakun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Opening new user registration activity using intent on button click.
                Intent intent = new Intent(Login_Kurir.this, Daftarkurir.class);
                startActivity(intent);

            }
        });
//////////////////////////////////////////////////////////////////////////////////////////////

        btnmasuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Username tidak boleh kosong!", Toast.LENGTH_SHORT).show();
                } else if (password.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Password tidak boleh kosong!", Toast.LENGTH_SHORT).show();
                } else {
                    progress = ProgressDialog.show(mContext, null,
                            "Harap Tunggu...",
                            true, false);

                    requestLogin(); // tester
                }
            }
        });
    }

    private void requestLogin() {
            mApiService.loginRequest(username.getText().toString(), password.getText().toString())
                    .enqueue(new Callback<ResponseBody>() {
                        @Override
                        public void onResponse(Call<ResponseBody> call, retrofit2.Response<ResponseBody> response) {
                            if (response.isSuccessful()) {
                                progress.dismiss();
                                try {
                                    JSONObject jsonRESULTS = new JSONObject(response.body().string());

                                    // jika login berhasil (sukses)
                                    if (jsonRESULTS.getString("error").equals("false")) {
//                                    SH_TOAST2("Hai '" + jsonRESULTS.getJSONObject("user").getString("nama") + "'");

                                        // parsing data
                                        String username = jsonRESULTS.getJSONObject("user").getString("username");
                                        String nama = jsonRESULTS.getJSONObject("user").getString("nama");

                                        sesion.setSudahLogin(true, new String[]{ username,nama});

                                        Intent intent = new Intent(mContext, FormKurir.class);
                                        startActivity(intent);
                                        finish();

                                    } else {
                                        // Jika login gagal
                                        String error_message = jsonRESULTS.getString("error_msg");
                                        SH_ALERT("Gagal Login !", error_message, "OK");
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                progress.dismiss();
                            }
                        }

                        @Override
                        public void onFailure(Call<ResponseBody> call, Throwable t) {
                            prinT("onFailure: ERROR > " + t.toString());

                            Toast.makeText(mContext, "UPPSS .. \n\n Koneksi Internet Bermasalah \n\n Periksa kembali koneksi anda!", Toast.LENGTH_SHORT).show();
                            progress.dismiss();
                        }
                    });
        }

        // TOASH LONG
        public void SH_TOAST2(String query) {
            Toast.makeText(Login_Kurir.this, query, Toast.LENGTH_LONG).show();
        }


        // ALERT DIALOG
        public void SH_ALERT(String judul, String msg, String button) {
            AlertDialog alertDialog = new AlertDialog.Builder(Login_Kurir.this).create();
            alertDialog.setTitle(judul);
            alertDialog.setCancelable(false);
            alertDialog.setMessage(msg);
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, button,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }

        // PRINT
        public void prinT(String msg) {
            System.out.println("---> " + msg);
        }
    }


//////////////////////////////////////////////////////////////////////////////////////////////

        /*
        // Methos to handleClick Event of Sign In Button
        public void signIn(View V){

        final Dialog dialog = new Dialog(Login_Kurir.this);
        dialog.setContentView(R.layout.activity_login_kurir);
        dialog.setTitle("");


        // get the Refferences of views
            final EditText editTextUserName = (EditText) dialog.findViewById(R.id.txUsername);
            final EditText editTextPassword = (EditText) dialog.findViewById(R.id.txPass);

            // Set On ClickListener
            btnmasuk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // get The User name and Password
                    String userName = editTextUserName.getText().toString();
                    String password = editTextPassword.getText().toString();

                    // fetch the Password form database for respective user name
                    String storedPassword = loginDataBaseAdapter.getSinlgeEntry(userName);

                    // check if the Stored password matches with  Password entered by user
                    if (password.equals(storedPassword)) {

                        sesion.createSession(editTextUserName.getText().toString());

                        Toast.makeText(Login_Kurir.this, "Congrats: Login Successfull", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Login_Kurir.this, FormKurir.class);
                        intent.putExtra("username", userName);
                        intent.putExtra("password", password);

                        startActivity(intent);
                        dialog.dismiss();
                    } else {
                        Toast.makeText(Login_Kurir.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
                    }
                }


            });

            dialog.show();
        }

        @Override
        protected void onDestroy () {
            super.onDestroy();
            // Close The Database
            loginDataBaseAdapter.close();
        }
    }
*/