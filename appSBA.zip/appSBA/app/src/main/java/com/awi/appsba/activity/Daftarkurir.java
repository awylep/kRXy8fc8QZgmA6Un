package com.awi.appsba.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.awi.appsba.R;
import com.awi.appsba.adapterLogin.LoginDataBaseAdapter;
import com.awi.appsba.api.BaseApiService;
import com.awi.appsba.api.UtilsApi;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Daftarkurir extends AppCompatActivity {


    Button bregister;
    //private static final String RG = "https://localhost/sbaapp/apis/register.php";
   // private final String serverUrl = "http://localhost/sbaapp/apis/register.php";

    EditText username, Nama, Instansi, Alamat, Email, password;
    Animation ttb, btt;
    TextView df;

    BaseApiService mApiService;
    ProgressDialog loading;
    Context mContext;

    // LoginDataBaseAdapter loginDataBaseAdapter;
   // protected String enteredusername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.daftarkurir);

        mContext = this;
        mApiService = UtilsApi.getAPIService();

        // get Instance  of Database Adapter
      //  loginDataBaseAdapter = new LoginDataBaseAdapter(this);
      //  loginDataBaseAdapter = loginDataBaseAdapter.open();

        bregister = (Button) findViewById(R.id.btndaftar);
        username = (EditText) findViewById(R.id.ednik_kurir);
        Nama = (EditText) findViewById(R.id.edkurir);
        Instansi = (EditText) findViewById(R.id.edinstansikurir);
        Alamat = (EditText) findViewById(R.id.edalamatkurir);
        Email = (EditText) findViewById(R.id.edemailkurir);
        df = (TextView) findViewById(R.id.txdaf);
        password = (EditText) findViewById(R.id.edpasskurir);


// load animation
        ttb = AnimationUtils.loadAnimation(this, R.anim.ttb);
        btt = AnimationUtils.loadAnimation(this, R.anim.btt);
// run animation
        df.startAnimation(ttb);
        username.startAnimation(btt);
        Nama.startAnimation(btt);
        Instansi.startAnimation(btt);
        Alamat.startAnimation(btt);
        Email.startAnimation(btt);
        password.startAnimation(btt);

        bregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Nama.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Nama tidak boleh kosong!", Toast.LENGTH_LONG).show();
                } else if (username.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Username tidak boleh kosong!", Toast.LENGTH_SHORT).show();
                } else if (password.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Password tidak boleh kosong!", Toast.LENGTH_SHORT).show();
                } else if (Instansi.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Instansi tidak boleh kosong!", Toast.LENGTH_SHORT).show();
                }  else if (Alamat.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Alamat tidak boleh kosong!", Toast.LENGTH_SHORT).show();
                }  else if (Email.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Email tidak boleh kosong!", Toast.LENGTH_SHORT).show();
                 } else {
                    loading = ProgressDialog.show(mContext, null,
                            "Harap Tunggu...",
                            true, false);

                    requestRegister();
                }
            }
        });
    }

    private void requestRegister() {
        mApiService.registerRequest(
                 username.getText().toString(),
                 Nama.getText().toString(),
                 Instansi.getText().toString(),
                 Alamat.getText().toString(),
                 Email.getText().toString(),
                 password.getText().toString())
                .enqueue(new Callback<ResponseBody>() {
                             @Override
                             public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                                 if (response.isSuccessful()) {

                                     Log.i("debug", "onResponse: Register BERHASIL");
                                     loading.dismiss();

                                     Toast.makeText(mContext, "BERHASIL REGISTRASI", Toast.LENGTH_SHORT).show();
                                     Intent intent = new Intent(getApplicationContext(), Login_Kurir.class);
                                     startActivity(intent);
                                     finish();
                                 } else {
                                     Log.i("debug", "onResponse: GAGAL REGISTRASI!");
                                     loading.dismiss();

                                     Toast.makeText(mContext, "GAGAL REGISTRASI !", Toast.LENGTH_SHORT).show();
                                 }
                             }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.i("debug", "onFailure: ERROR > " + t.getMessage());
                        Toast.makeText(mContext, "Koneksi Internet Bermasalah !", Toast.LENGTH_SHORT).show();
                        loading.dismiss();
                    }
                });
    }
}

 /*
    String userName = username.getText().toString();
                String nama = Nama.getText().toString();
                String instansi = Instansi.getText().toString();
                String alamat = Alamat.getText().toString();
                String email = Email.getText().toString();
                String pass = password.getText().toString();

                // check if any of the fields are vaccant
                if (userName.equals("") || password.equals("") || nama.equals("") || instansi.equals("") || alamat.equals("") || email.equals("")) {
                    Toast.makeText(getApplicationContext(), "Field Vaccant", Toast.LENGTH_LONG).show();
                    return;
                }

                // Save the Data in Database
                loginDataBaseAdapter.insertEntry(userName, pass,nama, instansi,alamat, email);
                Toast.makeText(getApplicationContext(), "Account Successfully Created ", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Daftarkurir.this, Login_Kurir.class);
                startActivity(intent);

            }
        });
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();

        loginDataBaseAdapter.close();
    }
} */