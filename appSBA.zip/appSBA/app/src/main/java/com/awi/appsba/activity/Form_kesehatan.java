package com.awi.appsba.activity;


import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.awi.appsba.R;


public class Form_kesehatan extends AppCompatActivity {

    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6;
    RadioButton yes1, no1, yes2, no2, yes3, no3, yes4, no4, yes5, no5, yes6, no6;
    CheckBox cb1;
    Button tmbllanjut;
    String Syes1, Sno1, Syes2, Sno2, Syes3, Sno3, Syes4, Sno4, Syes5, Sno5, Syes6, Sno6, Scb1;
    String Srg1, Srg2, Srg3, Srg4, Srg5, Srg6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_kesehatan);

        rg1 = (findViewById(R.id.rg1));
        rg2 = (findViewById(R.id.rg2));
        rg3 = (findViewById(R.id.rg3));
        rg4 = (findViewById(R.id.rg4));
        rg5 = (findViewById(R.id.rg5));
        rg6 = (findViewById(R.id.rg6));

        yes1 = (findViewById(R.id.RByes1));
        yes2 = (findViewById(R.id.RByes2));
        yes3 = (findViewById(R.id.RByes3));
        yes4 = (findViewById(R.id.RByes4));
        yes5 = (findViewById(R.id.RByes5));
        yes6 = (findViewById(R.id.RByes6));

        no1 = (findViewById(R.id.RBno1));
        no2 = (findViewById(R.id.RBno2));
        no3 = (findViewById(R.id.RBno3));
        no4 = (findViewById(R.id.RBno4));
        no5 = (findViewById(R.id.RBno5));
        no6 = (findViewById(R.id.RBno6));

        cb1 = (findViewById(R.id.cb1));

        tmbllanjut = (findViewById(R.id.tmbllanjut));

        Syes1 = yes1.toString();
        Syes2 = yes2.toString();
        Syes3 = yes3.toString();
        Syes4 = yes4.toString();
        Syes5 = yes5.toString();
        Syes6 = yes6.toString();

        Sno1 = no1.toString();
        Sno2 = no2.toString();
        Sno3 = no3.toString();
        Sno4 = no4.toString();
        Sno5 = no5.toString();
        Sno6 = no6.toString();

        Scb1 = cb1.toString();

        Srg1 = rg1.toString();
        Srg2 = rg2.toString();
        Srg3 = rg3.toString();
        Srg4 = rg4.toString();
        Srg5 = rg5.toString();
        Srg6 = rg6.toString();

    }
        /*        tmbllanjut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        addDataToDatabase(Syes1, Syes2, Syes3, Syes4, Syes5, Syes6, Sno1, Sno2, Sno3, Sno4, Sno5, Sno6);
                    }
                });





    private void addDataToDatabase(String syes1, String syes2, String syes3, String syes4, String syes5, String syes6, String sno1, String sno2, String sno3, String sno4, String sno5, String sno6) {
        String url = "https://sbatestapp.000webhostapp.com/vsa2021/datakrywn.php";
        RequestQueue queue = Volley.newRequestQueue(Form_kesehatan.this);
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("TAG", "RESPONSE IS" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(Form_kesehatan.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Form_kesehatan.this, "Gagal mendapatkan respon =" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded; charset=UTF-8";
            }

            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Syes1", Syes1);
                params.put("Syes2", Syes2);
                params.put("Syes3", Syes3);
                params.put("Syes4", Syes4);
                params.put("Syes5", Syes5);
                params.put("Syes6", Syes6);

                params.put("Sno1", Sno1);
                params.put("Sno2", Sno2);
                params.put("Sno3", Sno3);
                params.put("Sno4", Sno4);
                params.put("Sno5", Sno5);
                params.put("Sno6", Sno6);
                return params;
            }
        };

        queue.add(request); */
    }
